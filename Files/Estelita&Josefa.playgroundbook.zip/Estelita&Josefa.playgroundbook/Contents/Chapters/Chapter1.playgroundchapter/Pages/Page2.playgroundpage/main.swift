//: ## Now, we’re going to try to make a mask together.
//:
/*:
 In this step, all you have to do is drag an image on top of the other and, after that, click on the “Next Step” button. */
