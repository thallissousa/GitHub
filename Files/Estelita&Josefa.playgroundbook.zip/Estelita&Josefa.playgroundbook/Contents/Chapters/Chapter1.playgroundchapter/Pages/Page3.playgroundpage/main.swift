//: ## You made it!
/*:
 That was the story i've wanted to show you. As a periferic area resident, everyday I witness stories like this one of Estelita and Josefa, and have tried to show one of the ways that we might try to keep surviving besides everything we're facing. I hope you like it!

"Women.png" was created by studiogstock:  https://www.freepik.com/vectors/character, on www.freepik.com
 */

