import PlaygroundSupport
import UIKit
import Module

PlaygroundPage.current.setLiveView(ThanksAndGoodbye())

