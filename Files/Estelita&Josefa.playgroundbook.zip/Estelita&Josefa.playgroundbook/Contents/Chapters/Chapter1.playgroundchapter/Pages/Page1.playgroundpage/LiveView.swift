import PlaygroundSupport
import Module
let main = Main()

main.setPage(PlaygroundPage.current)
PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.setLiveView(main)

