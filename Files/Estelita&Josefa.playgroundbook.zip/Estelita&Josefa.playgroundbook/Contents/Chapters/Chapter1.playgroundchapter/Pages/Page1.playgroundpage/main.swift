//: ## Welcome, everyone!
/*:
 I'm Thallis, a psychology student from Brazil, and today I'm going to tell you a story about some brave women that have to face new ways to keep surviving during the COVID-19 pandemic. Let's go!
 */
